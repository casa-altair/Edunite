# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module for School Evaluation Management System
# ----------------------------------------------------------

from . import models
from . import wizard
