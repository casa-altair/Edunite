# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module for School Fees Management System
# ----------------------------------------------------------

from . import report
from . import models
from . import wizard
